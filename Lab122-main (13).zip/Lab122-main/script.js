
// source for the tablesorting code: "https://codepen.io/dcode-software/pen/zYGOrzK"
/*Table sorting code (TASK 1)
Alapatically and numerically Sorts any added table contents, by deconstructing the original table and the re-constructing the table in numerical and alphabetical order.
*/
function sortTableByColumn(table, column, asc = true) {
    const dirModifier = asc ? 1 : -1;
    const tBody = table.tBodies[0];
    const rows = Array.from(tBody.querySelectorAll("tr"));

    // Sort each row
    const sortedRows = rows.sort((a, b) => {
        const aColText = a.querySelector(`td:nth-child(${ column + 1 })`).textContent.trim();
        const bColText = b.querySelector(`td:nth-child(${ column + 1 })`).textContent.trim();

        return aColText > bColText ? (1 * dirModifier) : (-1 * dirModifier);
    });

    // Remove all existing TRs from the table
    while (tBody.firstChild) {
        tBody.removeChild(tBody.firstChild);
    }

    // Re-add the newly sorted rows
    tBody.append(...sortedRows);

    // Remember how the column is currently sorted
    table.querySelectorAll("th").forEach(th => th.classList.remove("th-sort-asc", "th-sort-desc"));
    table.querySelector(`th:nth-child(${ column + 1})`).classList.toggle("th-sort-asc", asc);
    table.querySelector(`th:nth-child(${ column + 1})`).classList.toggle("th-sort-desc", !asc);
}

document.querySelectorAll(".table-sortable th").forEach(headerCell => {
    headerCell.addEventListener("click", () => {
        const tableElement = headerCell.parentElement.parentElement.parentElement;
        const headerIndex = Array.prototype.indexOf.call(headerCell.parentElement.children, headerCell);
        const currentIsAscending = headerCell.classList.contains("th-sort-asc");

        sortTableByColumn(tableElement, headerIndex, !currentIsAscending);
    });
});

/*Code for Task 2
Assigns a button with a function which resets any added items which havnt already existed in the data base.
Additionaly an alert function is called which outputs any contents that are currently within the database. 
*/
$(document).ready(function(){
  $("button").click(function(){
    $.get("https://wt.ops.labs.vu.nl/api22/4dc7a89f/reset", function(data, status){
      alert("Data: " + data + "\nStatus: " + status);
    });
  });
});

// CODE FOR THE DYNAMIC TABLE (TASK 3)
/* The code for task 3 send an AJAX GET (with jquery) request to the webserver
to fill the table with content dynamically. The returened JSON data is then
inserted into the table using the DOM. 
*/

$(document).ready(function(){
      $.ajax({
          url:"https://wt.ops.labs.vu.nl/api22/4dc7a89f",
          type: "GET",
          dataType: "json",
          success: function(data){
        var phoneData = '';
        $.each(data,function(key,value){
          phoneData += '<tr>';
          phoneData += '<td>' + value.brand + '</td>';
          phoneData += '<td>' + value.model + '</td>';
          phoneData += '<td>' + value.os + '</td>';
          phoneData += '<td>' + value.screensize + '</td>';
          phoneData += '<td>' + value.image + '</td>';
          phoneData += '</tr>';
          
        });
        $("#phonedata").append(phoneData);
      },
          error: function(){
    alert("error loading phone data");
    }
    });
    
      // CODE FOR TASK 4
      /* This code for task 4 is to submit form data posted in JSON using the AJAX POST request
      and dynamically add it to our HTML table using the DOM, without refreshing the page.
      We were able to post the data to the server, but when we did (pressed "submit") we got the page with the
      URI (wich should not happen) and if we pressed the back arrow to go back to our website the table is updated with the 
      newly added data. We tried to fix this, but we didn't find a good soluton to this problem.We also tried doing 
      the POST method first then the GET method, but there was no difference.
      */
      var $newphoneData = $('#phonedata'); 
      var $brand = $('#brand');
      var $model = $('#model');
      var $os = $('#os');
      var $screensize = $('#screensize');
      var $image = $('#image');
      
      $('form').on('Submit',function(){
      
      event.preventDefault(this);
      var phonesData = {
      brand: $brand.val(),
      model: $model.val(),
      os: $os.val(),
      screensize: $screensize.val(),
      image: $image.val(),
      };
      
      $.ajax({
      url:"https://wt.ops.labs.vu.nl/api22/4dc7a89f",
      type: "POST",
      data: "phonesData",
      dataType: "json",
      success: function(newData){
      $newphoneData.append('<tr>');
      $newphoneData.append('<td>' + newData.brand + '</td>');
      $newphoneData.append('<td>' + newData.model + '</td>');
      $newphoneData.append('<td>' + newData.os + '</td>');
      $newphoneData.append('<td>' + newData.screensize + '</td>');
      $newphoneData.append('<td>' + newData.image + '</td>');
      $newphoneData.append('</tr>');
      
      },
          error: function(){
      alert("error updating/uploading new phone data");
      }
     });
    });    
   });

